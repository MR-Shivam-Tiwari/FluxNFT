import Layout from './Layout';

export default function Page() {
    return (
        <Layout>
            <h2>Epics Content</h2>
        </Layout>
    );
}
