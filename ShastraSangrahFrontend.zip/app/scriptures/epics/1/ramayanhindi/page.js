import NotAvailble from '@/app/NotAvailble'
import React from 'react'

function page() {
    return (
        <div>
            <NotAvailble />
        </div>
    )
}

export default page